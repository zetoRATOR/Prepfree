-- Fetches a small candidate pool of questions closest to the user's current
-- ability (theta), filtered and limited IN THE DATABASE — never a bare
-- "select * from questions where subject = X" pulled into app memory
-- (that pattern doesn't scale past a few hundred questions per subject).
create or replace function get_next_questions(
  p_subject text,
  p_theta numeric,
  p_exclude uuid[],
  p_count int default 5
)
returns setof questions
language sql
stable
as $$
  select *
  from questions
  where subject_code = p_subject
    and not (id = any(p_exclude))
  order by abs(irt_b - p_theta) asc
  limit greatest(p_count * 3, 10);
$$;

-- Refresh the leaderboard on a schedule instead of per page load.
-- Requires pg_cron extension (enable it in Supabase: Database > Extensions).
select cron.schedule(
  'refresh-leaderboard',
  '*/5 * * * *',
  $$ refresh materialized view concurrently leaderboard_snapshot $$
);
