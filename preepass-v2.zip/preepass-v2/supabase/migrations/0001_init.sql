-- PREEPASS v2 schema. RLS is enabled in the SAME migration every table is
-- created in -- never as a later "temporarily disable, fix later" step.
-- That "temporarily" is exactly how the v1 app ended up with RLS disabled
-- permanently on every table with a public anon key. Not repeating that here.

create extension if not exists "pgcrypto";

-- ============ PROFILES ============
-- 1:1 extension of auth.users. No password column exists anywhere in this
-- schema -- Supabase Auth (Google OAuth) owns identity entirely.
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  avatar_url text,
  role text not null default 'student' check (role in ('student','manager','admin')),
  exam_target text,
  created_at timestamptz not null default now()
);

-- Auto-create a profile row the moment someone signs in via Google.
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id, new.email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'avatar_url'
  );
  return new;
end;
$$ language plpgsql security definer set search_path = public;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============ ADAPTIVE STATE ============
-- Split from profiles: this row gets rewritten on every single answer, so
-- we don't want the whole profile (name, avatar, role...) rewritten with it.
create table adaptive_state (
  user_id uuid primary key references profiles(id) on delete cascade,
  theta_by_concept jsonb not null default '{}'::jsonb,
  overall_theta numeric not null default 0.0,
  updated_at timestamptz not null default now()
);

create function public.handle_new_profile()
returns trigger as $$
begin
  insert into public.adaptive_state (user_id) values (new.id);
  return new;
end;
$$ language plpgsql security definer set search_path = public;

create trigger on_profile_created
  after insert on profiles
  for each row execute procedure public.handle_new_profile();

-- ============ QUESTIONS ============
create table questions (
  id uuid primary key default gen_random_uuid(),
  subject_code text not null,
  chapter text,
  concept text,
  question_text text not null,
  options jsonb not null,               -- [{id, text}, ...]
  correct_option_id text not null,
  explanation text,
  difficulty_level int not null default 5,
  irt_a numeric not null default 1.0,   -- discrimination
  irt_b numeric not null default 0.0,   -- difficulty, same scale as theta
  normalized_hash text not null,        -- dedup key: hash(subject+chapter+normalized text)
  generated_by text not null default 'human' check (generated_by in ('human','ai')),
  uploaded_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create unique index idx_questions_dedup on questions (subject_code, chapter, normalized_hash);
create index idx_questions_subject_difficulty on questions (subject_code, irt_b);
create index idx_questions_subject_chapter on questions (subject_code, chapter, irt_b);

-- ============ PYQ (previous year questions) ============
create table pyq_papers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  year int,
  duration_minutes int,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table pyq_questions (
  id uuid primary key default gen_random_uuid(),
  paper_id uuid not null references pyq_papers(id) on delete cascade,
  subject text,
  chapter text,
  question_text text not null,
  options jsonb not null,
  correct_option_index int not null,
  explanation text,
  created_at timestamptz not null default now()
);
create index idx_pyq_questions_paper on pyq_questions (paper_id);

-- ============ TEST SESSIONS + ATTEMPTS ============
create table test_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  mock_type text,                        -- null = adaptive practice
  subject text,
  status text not null default 'active' check (status in ('active','submitted','abandoned')),
  question_ids uuid[] not null default '{}',
  created_at timestamptz not null default now(),
  submitted_at timestamptz
);
create index idx_sessions_user_status on test_sessions (user_id, status);

create table user_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  test_id uuid not null references test_sessions(id) on delete cascade,
  question_id uuid not null references questions(id) on delete cascade,
  chosen_option_id text,
  is_correct boolean not null default false,
  time_taken_seconds int not null default 0,
  created_at timestamptz not null default now()
);
create index idx_attempts_user_question on user_attempts (user_id, question_id);
create index idx_attempts_test_user on user_attempts (test_id, user_id);
-- Prevent double-answering the same question twice in the same session
-- (this is what closes the "resubmit the same question_id" bug class from v1).
create unique index idx_attempts_no_dupe on user_attempts (test_id, question_id);

-- ============ SUBSCRIPTIONS ============
create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  plan text not null,
  status text not null default 'active' check (status in ('active','expired','cancelled')),
  starts_at timestamptz not null default now(),
  ends_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index idx_subscriptions_user on subscriptions (user_id);

-- ============ LEADERBOARD (materialized, refreshed on a schedule) ============
create materialized view leaderboard_snapshot as
  select
    p.id as user_id,
    p.full_name,
    count(*) filter (where a.is_correct) as correct_count,
    count(*) as attempt_count,
    round(count(*) filter (where a.is_correct)::numeric / greatest(count(*), 1) * 100, 1) as accuracy
  from user_attempts a
  join profiles p on p.id = a.user_id
  group by p.id, p.full_name
  order by correct_count desc;

create unique index idx_leaderboard_user on leaderboard_snapshot (user_id);
