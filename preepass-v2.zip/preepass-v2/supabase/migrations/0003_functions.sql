-- Question selection happens IN the database: closest-difficulty-to-ability
-- candidates only, never a `select * from questions where subject = X` that
-- pulls the entire subject into application memory (that query, at scale,
-- was the single biggest scaling landmine in the v1 app).
create or replace function get_practice_candidates(
  p_subject text,
  p_theta numeric,
  p_exclude uuid[],
  p_count int
)
returns setof questions
language sql
stable
as $$
  select *
  from questions
  where subject_code = p_subject
    and not (id = any(p_exclude))
  order by abs(irt_b - p_theta) asc
  limit greatest(p_count * 3, 10);
$$;

-- Atomic, race-safe theta update: reads current state, applies one IRT step,
-- writes it back, all inside a single transaction-safe function instead of
-- a read-then-write round trip from the app layer.
create or replace function update_theta_after_attempt(
  p_user_id uuid,
  p_concept text,
  p_is_correct boolean,
  p_irt_a numeric,
  p_irt_b numeric
)
returns numeric
language plpgsql
as $$
declare
  v_theta numeric;
  v_step numeric := 0.35; -- ability-update step size, tune via real data later
begin
  select coalesce((theta_by_concept->>p_concept)::numeric, 0.0)
    into v_theta
    from adaptive_state where user_id = p_user_id;

  -- Simple bounded gradient step toward/away from the item's difficulty,
  -- scaled by discrimination. This is intentionally simple and replaceable --
  -- see lib/adaptiveEngine.ts for the fuller Fisher-information version used
  -- for question SELECTION; this function only needs to keep theta moving
  -- correctly and atomically.
  if p_is_correct then
    v_theta := v_theta + v_step * p_irt_a;
  else
    v_theta := v_theta - v_step * p_irt_a;
  end if;

  update adaptive_state
    set theta_by_concept = jsonb_set(theta_by_concept, array[p_concept], to_jsonb(v_theta)),
        overall_theta = (
          select avg((value)::numeric)
          from jsonb_each_text(jsonb_set(theta_by_concept, array[p_concept], to_jsonb(v_theta)))
        ),
        updated_at = now()
    where user_id = p_user_id;

  return v_theta;
end;
$$;
