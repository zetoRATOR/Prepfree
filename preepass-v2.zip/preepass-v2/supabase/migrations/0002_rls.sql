-- Row Level Security. This is the actual security boundary for the app --
-- not the Next.js route handlers, which are a fast-fail UX nicety on top.
-- Even if a route handler has a bug, the database itself will refuse to
-- return or write a row that doesn't belong to the caller.

alter table profiles enable row level security;
alter table adaptive_state enable row level security;
alter table questions enable row level security;
alter table pyq_papers enable row level security;
alter table pyq_questions enable row level security;
alter table test_sessions enable row level security;
alter table user_attempts enable row level security;
alter table subscriptions enable row level security;

-- Helper: is the current user staff (manager/admin)?
create function public.is_staff()
returns boolean as $$
  select exists (
    select 1 from profiles
    where id = auth.uid() and role in ('manager','admin')
  );
$$ language sql security definer stable set search_path = public;

-- ---------- profiles ----------
create policy "read own profile" on profiles
  for select using (auth.uid() = id or is_staff());
create policy "update own profile" on profiles
  for update using (auth.uid() = id);
-- No insert policy: profiles are only created by the on_auth_user_created
-- trigger (security definer), never directly by a client.
-- No general delete policy: account deletion is a server-side, audited action.

-- ---------- adaptive_state ----------
create policy "read own adaptive state" on adaptive_state
  for select using (auth.uid() = user_id or is_staff());
create policy "update own adaptive state" on adaptive_state
  for update using (auth.uid() = user_id);

-- ---------- questions ----------
-- Any authenticated (paying or not -- gate that in app logic/subscriptions,
-- not by hiding rows) user can read questions to practice with.
create policy "read questions" on questions
  for select using (auth.role() = 'authenticated');
-- Only staff can write. Students get no insert/update/delete policy at all,
-- which means those operations are denied by default -- not "checked
-- somewhere in Express and hopefully not forgotten."
create policy "staff manage questions" on questions
  for all using (is_staff()) with check (is_staff());

-- ---------- pyq content ----------
create policy "read pyq papers" on pyq_papers
  for select using (auth.role() = 'authenticated');
create policy "staff manage pyq papers" on pyq_papers
  for all using (is_staff()) with check (is_staff());
create policy "read pyq questions" on pyq_questions
  for select using (auth.role() = 'authenticated');
create policy "staff manage pyq questions" on pyq_questions
  for all using (is_staff()) with check (is_staff());

-- ---------- test_sessions ----------
create policy "own sessions" on test_sessions
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "staff read all sessions" on test_sessions
  for select using (is_staff());

-- ---------- user_attempts ----------
create policy "own attempts" on user_attempts
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "staff read all attempts" on user_attempts
  for select using (is_staff());

-- ---------- subscriptions ----------
-- Students can READ their own subscription, but can never write one --
-- activation only happens server-side (service role, after payment
-- verification), which is what stops the v1 "unauthenticated
-- /api/subscriptions/activate" hole from being possible even in principle.
create policy "read own subscription" on subscriptions
  for select using (auth.uid() = user_id or is_staff());
create policy "staff manage subscriptions" on subscriptions
  for all using (is_staff()) with check (is_staff());
