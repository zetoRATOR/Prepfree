# PREEPASS v2

A working Next.js (App Router) + Supabase rebuild of PREEPASS, built directly
against the findings of the earlier audit of the original codebase. This is
real, runnable code -- not a spec -- covering the parts that mattered most:
identity, security, the adaptive engine, and the question-fetch path.

## What's actually implemented here

- **Auth**: Google sign-in only, via Supabase Auth (`app/login`,
  `app/auth/callback`). No passwords, no JWT signing, no bcrypt anywhere in
  this codebase -- removing the entire bug class the original app had from
  running two competing auth systems side by side.
- **Database + RLS** (`supabase/migrations/`): every table has Row Level
  Security enabled in the same migration it's created in. The original
  app's `database_migration.sql` disabled RLS on every table with the
  comment "Disable RLS due to public anon key usage" -- that line is why
  this rebuild treats RLS as non-negotiable from migration 0001, not an
  add-on.
- **Adaptive engine** (`lib/adaptiveEngine.ts` + `lib/__tests__/`): the IRT
  math (probability of correct response, Fisher information, ability→level
  mapping) ported as pure, tested functions -- the original math was
  correct, it just lived tangled inside a 3,688-line `server.ts` with zero
  test coverage.
- **Question fetching** (`get_practice_candidates` in
  `0003_functions.sql`): filtering happens in Postgres, returning a small
  candidate pool -- never a `select *` for an entire subject pulled into
  Node memory, which was the biggest scaling risk found in the original
  app.
- **Test submission** (`app/api/test/submit/route.ts`): direct option-ID
  comparison, not the original's `parseInt(chosen_option_id.slice(-1))`
  string-slicing hack. A unique index (`idx_attempts_no_dupe`) makes a
  retried submit safe at the database level.
- **Test runner UI** (`components/TestRunner.tsx`): a single client
  component that transitions between questions with `framer-motion`
  instead of full page navigations, plus a confetti moment on a strong
  score.

## What you still need to do to run this for real

1. Create a Supabase project, then in **Authentication → Providers**,
   enable Google and add your OAuth client ID/secret (from Google Cloud
   Console).
2. Run the three migrations in `supabase/migrations/` in order, via the
   Supabase SQL editor or `supabase db push`.
3. Copy `.env.example` to `.env.local` and fill in your project URL and
   anon key (from **Project Settings → API**). Never put the service role
   key anywhere the browser can reach it.
4. `npm install && npm run dev`.
5. Seed some real questions with real `irt_a`/`irt_b` values -- everything
   ships with sane defaults (`irt_a = 1.0`, `irt_b = 0.0`), but the
   adaptive engine only gets genuinely useful once those parameters are
   calibrated from real response data over time.
6. Set up the leaderboard refresh schedule (needs the `pg_cron` extension
   enabled in your Supabase project):
   ```sql
   select cron.schedule('refresh-leaderboard', '*/5 * * * *',
     $$ refresh materialized view concurrently leaderboard_snapshot $$);
   ```

## What's intentionally NOT built yet

This covers the highest-leverage pieces first, matching the priority order
from the rebuild roadmap (security and correctness before polish):

- Mock test / PYQ runner pages (same `TestRunner` component works for
  these — they just need their own fetch routes analogous to
  `app/api/practice`)
- Admin question-upload UI (the RLS policy and route guard already exist
  in `app/admin/layout.tsx` — the page itself is a straightforward form)
- Subscriptions/payment webhook handling (deliberately server-side only,
  using `lib/supabase/service.ts` — never activate a subscription from a
  client-trusted call)
- AI question generation via Gemini, with the dedup/cost controls
  described in the earlier report

## Testing

```
npm i -D vitest
npx vitest run
```
`lib/__tests__/adaptiveEngine.test.ts` covers the core IRT functions --
the original app shipped with zero automated tests, which is exactly how
a silent scoring bug went unnoticed in production.
