import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';

// This check is a fast-fail UX nicety, NOT the real security boundary --
// the real boundary is the "staff manage questions" RLS policy in
// 0002_rls.sql, which the database enforces regardless of whether this
// layout check is ever bypassed, forgotten, or has a bug in it.
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (!profile || !['admin', 'manager'].includes(profile.role)) {
    redirect('/dashboard');
  }

  return <div className="min-h-screen">{children}</div>;
}
