import { createClient } from '@/lib/supabase/server';
import { thetaToLevel } from '@/lib/adaptiveEngine';
import Link from 'next/link';
import { redirect } from 'next/navigation';

// Server Component: data fetched and rendered on the server, RLS enforced
// with the signed-in user's own session -- no client-trusted identity of
// any kind reaches this page.
export default async function DashboardPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const [{ data: profile }, { data: adaptiveState }, { data: recentSessions }] = await Promise.all([
    supabase.from('profiles').select('full_name, exam_target').eq('id', user.id).single(),
    supabase.from('adaptive_state').select('theta_by_concept, overall_theta').eq('user_id', user.id).single(),
    supabase.from('test_sessions').select('id, subject, status, created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(5),
  ]);

  const overallLevel = thetaToLevel(adaptiveState?.overall_theta ?? 0);
  const subjectLevels = Object.entries(adaptiveState?.theta_by_concept ?? {}).map(
    ([subject, theta]) => ({ subject, level: thetaToLevel(theta as number) })
  );

  return (
    <main className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="text-xl font-medium text-neutral-900 dark:text-neutral-100">
        Welcome back{profile?.full_name ? `, ${profile.full_name.split(' ')[0]}` : ''}
      </h1>
      <p className="mt-1 text-sm text-neutral-500">
        Overall level: <span className="font-medium">{overallLevel}</span>
        {profile?.exam_target ? ` · Prepping for ${profile.exam_target}` : ''}
      </p>

      <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Link href="/practice" className="rounded-lg border border-neutral-200 p-4 text-sm font-medium hover:bg-neutral-50 dark:border-neutral-800 dark:hover:bg-neutral-900">
          Practice
        </Link>
        <Link href="/mock-test" className="rounded-lg border border-neutral-200 p-4 text-sm font-medium hover:bg-neutral-50 dark:border-neutral-800 dark:hover:bg-neutral-900">
          Mock test
        </Link>
        <Link href="/pyq" className="rounded-lg border border-neutral-200 p-4 text-sm font-medium hover:bg-neutral-50 dark:border-neutral-800 dark:hover:bg-neutral-900">
          Previous years
        </Link>
        <Link href="/leaderboard" className="rounded-lg border border-neutral-200 p-4 text-sm font-medium hover:bg-neutral-50 dark:border-neutral-800 dark:hover:bg-neutral-900">
          Leaderboard
        </Link>
      </div>

      {subjectLevels.length > 0 && (
        <section className="mt-10">
          <h2 className="mb-3 text-sm font-medium text-neutral-700 dark:text-neutral-300">
            Level by subject
          </h2>
          <div className="space-y-2">
            {subjectLevels.map(({ subject, level }) => (
              <div key={subject} className="flex items-center justify-between rounded-md border border-neutral-100 px-3 py-2 text-sm dark:border-neutral-800">
                <span>{subject}</span>
                <span className="font-medium">Level {level}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {recentSessions && recentSessions.length > 0 && (
        <section className="mt-10">
          <h2 className="mb-3 text-sm font-medium text-neutral-700 dark:text-neutral-300">
            Recent activity
          </h2>
          <div className="space-y-2">
            {recentSessions.map((s) => (
              <div key={s.id} className="flex items-center justify-between rounded-md border border-neutral-100 px-3 py-2 text-sm dark:border-neutral-800">
                <span>{s.subject ?? 'Mixed practice'}</span>
                <span className="text-neutral-500">{s.status}</span>
              </div>
            ))}
          </div>
        </section>
      )}
    </main>
  );
}
