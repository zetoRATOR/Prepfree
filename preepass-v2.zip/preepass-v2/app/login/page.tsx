'use client';
import { createClient } from '@/lib/supabase/client';

export default function LoginPage() {
  const supabase = createClient();

  const signInWithGoogle = async () => {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/auth/callback` },
    });
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-white dark:bg-neutral-950">
      <div className="w-full max-w-sm text-center">
        <h1 className="mb-2 text-2xl font-medium text-neutral-900 dark:text-neutral-100">
          PREEPASS
        </h1>
        <p className="mb-8 text-sm text-neutral-500">
          Adaptive practice for CUET, CLAT, AILET and more.
        </p>
        <button
          onClick={signInWithGoogle}
          className="w-full rounded-lg border border-neutral-200 px-4 py-3 text-sm font-medium
                     text-neutral-800 transition hover:bg-neutral-50 dark:border-neutral-800
                     dark:text-neutral-100 dark:hover:bg-neutral-900"
        >
          Continue with Google
        </button>
      </div>
    </div>
  );
}
