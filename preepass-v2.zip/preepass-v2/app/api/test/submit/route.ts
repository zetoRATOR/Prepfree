import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

interface SubmittedResponse {
  question_id: string;
  chosen_option_id: string;
  time_taken_seconds: number;
}

export async function POST(request: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { sessionId, responses } = await request.json() as {
    sessionId: string;
    responses: SubmittedResponse[];
  };

  // RLS already guarantees this row belongs to `user`, but we still verify
  // status explicitly so a double-submit gives a clean error, not a
  // confusing partial write.
  const { data: session } = await supabase
    .from('test_sessions')
    .select('id, status, question_ids, subject')
    .eq('id', sessionId)
    .single();

  if (!session) return NextResponse.json({ error: 'Session not found' }, { status: 404 });
  if (session.status !== 'active') {
    return NextResponse.json({ error: 'Session already submitted' }, { status: 400 });
  }

  const allowedQuestionIds = new Set(session.question_ids);
  const { data: questions } = await supabase
    .from('questions')
    .select('id, correct_option_id, irt_a, irt_b, concept, subject_code')
    .in('id', session.question_ids);

  const questionMap = new Map((questions ?? []).map((q) => [q.id, q]));
  let correctCount = 0;
  const attemptRows = [];

  for (const r of responses) {
    if (!allowedQuestionIds.has(r.question_id)) {
      // Reject the whole submission rather than silently dropping one
      // answer -- a mismatched question_id means the client sent something
      // it was never issued, which should never happen from the real UI.
      return NextResponse.json({ error: 'Question not part of this session' }, { status: 403 });
    }
    const q = questionMap.get(r.question_id);
    if (!q) continue;

    // Direct ID comparison -- no string-slicing hacks on option ids like
    // v1's `parseInt(chosen_option_id.slice(-1))`. Explicit and correct.
    const isCorrect = r.chosen_option_id === q.correct_option_id;
    if (isCorrect) correctCount++;

    attemptRows.push({
      user_id: user.id,
      test_id: sessionId,
      question_id: r.question_id,
      chosen_option_id: r.chosen_option_id,
      is_correct: isCorrect,
      time_taken_seconds: r.time_taken_seconds ?? 0,
    });

    // Atomic theta update per question, in the database.
    await supabase.rpc('update_theta_after_attempt', {
      p_user_id: user.id,
      p_concept: q.concept ?? q.subject_code,
      p_is_correct: isCorrect,
      p_irt_a: q.irt_a,
      p_irt_b: q.irt_b,
    });
  }

  // `idx_attempts_no_dupe` (unique on test_id+question_id) makes a retried
  // submit safe: duplicate rows are rejected at the DB level, not just
  // guarded against by application logic that might have a gap in it.
  const { error: insertError } = await supabase.from('user_attempts').insert(attemptRows);
  if (insertError && insertError.code !== '23505') {
    console.error('Failed to insert attempts', insertError);
    return NextResponse.json({ error: 'Could not save attempts' }, { status: 500 });
  }

  await supabase
    .from('test_sessions')
    .update({ status: 'submitted', submitted_at: new Date().toISOString() })
    .eq('id', sessionId);

  return NextResponse.json({
    correctCount,
    totalCount: responses.length,
    scorePercent: Math.round((correctCount / Math.max(responses.length, 1)) * 100),
  });
}
