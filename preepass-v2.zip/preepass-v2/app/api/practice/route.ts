import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { selectMostInformative } from '@/lib/adaptiveEngine';

// Identity for this request comes ONLY from the authenticated Supabase
// session (auth.uid()) -- there is no client-supplied user-id header
// anywhere in this codebase. That single-source-of-identity rule is what
// closed the account-impersonation bug from the v1 audit.
export async function POST(request: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { subject, count = 5, seenQuestionIds = [] } = await request.json();
  if (!subject || typeof subject !== 'string') {
    return NextResponse.json({ error: 'subject is required' }, { status: 400 });
  }

  const { data: state } = await supabase
    .from('adaptive_state')
    .select('theta_by_concept, overall_theta')
    .eq('user_id', user.id)
    .single();

  const theta = state?.theta_by_concept?.[subject] ?? state?.overall_theta ?? 0;

  const { data: candidates, error } = await supabase.rpc('get_practice_candidates', {
    p_subject: subject,
    p_theta: theta,
    p_exclude: seenQuestionIds,
    p_count: count,
  });

  if (error) {
    console.error('get_practice_candidates failed', error);
    return NextResponse.json({ error: 'Could not fetch questions' }, { status: 500 });
  }

  // Fine-grained selection (most informative next item) happens on the
  // small candidate pool the DB already narrowed down -- not on a full
  // table scan pulled into memory.
  const selected: typeof candidates = [];
  const pool = [...(candidates ?? [])];
  for (let i = 0; i < count && pool.length > 0; i++) {
    const next = selectMostInformative(theta, pool);
    if (!next) break;
    selected.push(next);
    const idx = pool.findIndex((q) => q.id === next.id);
    pool.splice(idx, 1);
  }

  // Never send `correct_option_id` to the client.
  const safeQuestions = selected.map((q: { correct_option_id: string; [key: string]: unknown }) => {
    const { correct_option_id, ...rest } = q;
    return rest;
  });

  const { data: session, error: sessionError } = await supabase
    .from('test_sessions')
    .insert({
      user_id: user.id,
      subject,
      question_ids: selected.map((q: { id: string }) => q.id),
    })
    .select('id')
    .single();

  if (sessionError) {
    return NextResponse.json({ error: 'Could not create session' }, { status: 500 });
  }

  return NextResponse.json({ sessionId: session.id, questions: safeQuestions });
}
