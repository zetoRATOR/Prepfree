'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

const EXAMS = ['CUET', 'CLAT', 'AILET', 'SSC CGL', 'MBA entrance'];
// Self-assessed starting point -- seeds theta instead of starting every
// student flat at Level 1 regardless of where they actually are.
const STARTING_THETA = { Beginner: -1.0, Intermediate: 0, Advanced: 1.2 };

export default function OnboardingPage() {
  const router = useRouter();
  const supabase = createClient();
  const [exam, setExam] = useState(EXAMS[0]);
  const [level, setLevel] = useState<keyof typeof STARTING_THETA>('Intermediate');
  const [saving, setSaving] = useState(false);

  async function finish() {
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase.from('profiles').update({ exam_target: exam }).eq('id', user.id);
    await supabase
      .from('adaptive_state')
      .update({ overall_theta: STARTING_THETA[level] })
      .eq('user_id', user.id);

    router.push('/dashboard');
  }

  return (
    <main className="mx-auto max-w-md px-6 py-16">
      <h1 className="mb-1 text-lg font-medium">Which exam are you preparing for?</h1>
      <p className="mb-6 text-sm text-neutral-500">You can change this later.</p>

      <div className="mb-8 space-y-2">
        {EXAMS.map((e) => (
          <button
            key={e}
            onClick={() => setExam(e)}
            className={`w-full rounded-lg border px-4 py-3 text-left text-sm font-medium transition
              ${exam === e ? 'border-brand-600 bg-brand-50 dark:bg-brand-900/20' : 'border-neutral-200 dark:border-neutral-800'}`}
          >
            {e}
          </button>
        ))}
      </div>

      <h2 className="mb-3 text-sm font-medium text-neutral-700 dark:text-neutral-300">
        How would you rate your current level?
      </h2>
      <div className="mb-8 flex gap-2">
        {(Object.keys(STARTING_THETA) as (keyof typeof STARTING_THETA)[]).map((l) => (
          <button
            key={l}
            onClick={() => setLevel(l)}
            className={`flex-1 rounded-lg border px-3 py-2 text-sm transition
              ${level === l ? 'border-brand-600 bg-brand-50 dark:bg-brand-900/20' : 'border-neutral-200 dark:border-neutral-800'}`}
          >
            {l}
          </button>
        ))}
      </div>

      <button
        onClick={finish}
        disabled={saving}
        className="w-full rounded-lg bg-brand-600 px-4 py-3 text-sm font-medium text-white hover:bg-brand-800 disabled:opacity-50"
      >
        {saving ? 'Setting up...' : 'Start practicing'}
      </button>
    </main>
  );
}
