'use client';

import { useState } from 'react';
import TestRunner from '@/components/TestRunner';

const SUBJECTS = ['MATH', 'ENGLISH', 'REASONING', 'GA', 'LEGAL'];

export default function PracticePage() {
  const [session, setSession] = useState<{ sessionId: string; questions: any[] } | null>(null);
  const [loading, setLoading] = useState(false);

  async function start(subject: string) {
    setLoading(true);
    const res = await fetch('/api/practice', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subject, count: 5, seenQuestionIds: [] }),
    });
    const data = await res.json();
    setSession(data);
    setLoading(false);
  }

  if (session) {
    return <TestRunner sessionId={session.sessionId} questions={session.questions} />;
  }

  return (
    <main className="mx-auto max-w-md px-6 py-16">
      <h1 className="mb-6 text-lg font-medium">Choose a subject</h1>
      <div className="space-y-2">
        {SUBJECTS.map((s) => (
          <button
            key={s}
            onClick={() => start(s)}
            disabled={loading}
            className="w-full rounded-lg border border-neutral-200 px-4 py-3 text-left text-sm
                       font-medium hover:bg-neutral-50 disabled:opacity-50 dark:border-neutral-800
                       dark:hover:bg-neutral-900"
          >
            {s}
          </button>
        ))}
      </div>
    </main>
  );
}
