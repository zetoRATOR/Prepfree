import { createClient } from '@/lib/supabase/server';

// Reads the pre-computed leaderboard_snapshot materialized view -- refreshed
// on a schedule (see the README's pg_cron setup), not aggregated live on
// every page load. That's what lets this page stay fast under real traffic.
export default async function LeaderboardPage() {
  const supabase = createClient();
  const { data: rows } = await supabase
    .from('leaderboard_snapshot')
    .select('full_name, correct_count, accuracy')
    .order('correct_count', { ascending: false })
    .limit(50);

  return (
    <main className="mx-auto max-w-md px-6 py-10">
      <h1 className="mb-6 text-lg font-medium">Leaderboard</h1>
      <div className="space-y-1">
        {(rows ?? []).map((r, i) => (
          <div key={i} className="flex items-center justify-between rounded-md px-3 py-2 text-sm even:bg-neutral-50 dark:even:bg-neutral-900">
            <span>
              <span className="mr-3 text-neutral-400">{i + 1}</span>
              {r.full_name ?? 'Student'}
            </span>
            <span className="text-neutral-500">{r.correct_count} correct · {r.accuracy}%</span>
          </div>
        ))}
        {(!rows || rows.length === 0) && (
          <p className="text-sm text-neutral-500">No attempts yet — be the first on the board.</p>
        )}
      </div>
    </main>
  );
}
