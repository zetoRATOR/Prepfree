'use client';

import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import confetti from 'canvas-confetti';

interface Option { id: string; text: string; }
interface Question { id: string; question_text: string; options: Option[]; }

interface Props {
  sessionId: string;
  questions: Question[];
}

// Single client component that swaps question content in place -- no full
// Next.js route navigation between questions. That's the actual difference
// between a test-runner that "feels like an app" and one that "feels like
// a form," and it was called out specifically in the UX section of the spec.
export default function TestRunner({ sessionId, questions }: Props) {
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [startedAt] = useState(() => Date.now());
  const [questionStartedAt, setQuestionStartedAt] = useState(() => Date.now());
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ correctCount: number; totalCount: number; scorePercent: number } | null>(null);

  const current = questions[index];
  const isLast = index === questions.length - 1;

  function selectOption(optionId: string) {
    setAnswers((prev) => ({ ...prev, [current.id]: optionId }));
  }

  function goNext() {
    if (isLast) return submit();
    setIndex((i) => i + 1);
    setQuestionStartedAt(Date.now());
  }

  async function submit() {
    setSubmitting(true);
    const responses = questions.map((q) => ({
      question_id: q.id,
      chosen_option_id: answers[q.id] ?? '',
      time_taken_seconds: Math.round((Date.now() - questionStartedAt) / 1000),
    }));

    const res = await fetch('/api/test/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId, responses }),
    });
    const data = await res.json();
    setResult(data);
    setSubmitting(false);

    if (data.scorePercent >= 80) {
      confetti({ particleCount: 120, spread: 70, origin: { y: 0.6 } });
    }
  }

  if (result) {
    return (
      <div className="mx-auto max-w-md px-6 py-16 text-center">
        <p className="text-sm text-neutral-500">You scored</p>
        <p className="mt-1 text-4xl font-medium">{result.scorePercent}%</p>
        <p className="mt-2 text-sm text-neutral-500">
          {result.correctCount} of {result.totalCount} correct
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-xl px-6 py-10">
      <div className="mb-6 flex items-center justify-between text-xs text-neutral-500">
        <span>Question {index + 1} of {questions.length}</span>
        <div className="h-1 w-32 overflow-hidden rounded-full bg-neutral-100 dark:bg-neutral-800">
          <div
            className="h-full bg-brand-600 transition-all duration-300"
            style={{ width: `${((index + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={current.id}
          initial={{ opacity: 0, x: 16 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -16 }}
          transition={{ duration: 0.2 }}
        >
          <p className="mb-5 text-base font-medium text-neutral-900 dark:text-neutral-100">
            {current.question_text}
          </p>
          <div className="space-y-2">
            {current.options.map((opt) => {
              const selected = answers[current.id] === opt.id;
              return (
                <button
                  key={opt.id}
                  onClick={() => selectOption(opt.id)}
                  className={`w-full rounded-lg border px-4 py-3 text-left text-sm transition
                    ${selected
                      ? 'border-brand-600 bg-brand-50 text-brand-900 dark:bg-brand-900/20 dark:text-brand-100'
                      : 'border-neutral-200 hover:bg-neutral-50 dark:border-neutral-800 dark:hover:bg-neutral-900'}`}
                >
                  {opt.text}
                </button>
              );
            })}
          </div>
        </motion.div>
      </AnimatePresence>

      <button
        onClick={goNext}
        disabled={!answers[current.id] || submitting}
        className="mt-8 w-full rounded-lg bg-brand-600 px-4 py-3 text-sm font-medium text-white
                   transition disabled:cursor-not-allowed disabled:opacity-40 hover:bg-brand-800"
      >
        {submitting ? 'Submitting...' : isLast ? 'Finish test' : 'Next question'}
      </button>
    </div>
  );
}
