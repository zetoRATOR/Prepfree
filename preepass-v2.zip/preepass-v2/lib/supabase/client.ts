import { createBrowserClient } from '@supabase/ssr';

// Client-side Supabase client. Uses the PUBLIC anon key -- safe to ship,
// because every table it can touch is protected by the RLS policies in
// supabase/migrations/0002_rls.sql. This is the correct way to use a
// public anon key: the boundary is in Postgres, not in "don't expose this."
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
