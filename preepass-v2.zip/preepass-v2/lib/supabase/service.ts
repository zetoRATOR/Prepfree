import { createClient as createSupabaseClient } from '@supabase/supabase-js';

// SERVICE ROLE client -- bypasses RLS entirely. This must NEVER be imported
// into any file that ships to the browser, and must only be used for
// operations that genuinely require bypassing a user's own permissions
// (e.g. verifying a payment webhook, then activating a subscription).
// If you find yourself reaching for this to "make an error go away," stop --
// that instinct is exactly how v1 ended up with RLS disabled everywhere.
export function createServiceClient() {
  if (typeof window !== 'undefined') {
    throw new Error('Service role client must never be created in the browser.');
  }
  return createSupabaseClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}
