/**
 * Adaptive engine: Item Response Theory (2-parameter logistic model).
 * Ported from the v1 app's server.ts -- that math was genuinely correct,
 * it just never had real per-question a/b parameters to work with, and it
 * lived tangled inside a 3,688-line file next to routing and SQL. Here it's
 * pure, dependency-free, and independently testable.
 */

export interface QuestionItem {
  id: string;
  irt_a: number; // discrimination
  irt_b: number; // difficulty (same scale as theta)
}

/** Probability a student with ability `theta` answers this item correctly. */
export function irtProbCorrect(theta: number, a: number, b: number): number {
  return 1.0 / (1.0 + Math.exp(-a * (theta - b)));
}

/** Fisher information: how much this item would tell us about the student's
 *  ability if we asked it right now. Higher = more informative choice. */
export function fisherInformation(theta: number, a: number, b: number): number {
  const p = irtProbCorrect(theta, a, b);
  return a * a * p * (1 - p);
}

/** Pick the single most informative next question from a candidate pool. */
export function selectMostInformative(theta: number, candidates: QuestionItem[]): QuestionItem | null {
  if (candidates.length === 0) return null;
  return candidates.reduce((best, q) => {
    const info = fisherInformation(theta, q.irt_a, q.irt_b);
    const bestInfo = fisherInformation(theta, best.irt_a, best.irt_b);
    return info > bestInfo ? q : best;
  }, candidates[0]);
}

/** Convert a raw theta value into a human-facing level (roughly 1-20). */
export function thetaToLevel(theta: number): number {
  return Math.max(1, Math.round(4.0 * theta + 8.0));
}

/** Spaced repetition: simple SM-2-inspired due-date scheduling per concept. */
export interface ReviewEntry {
  conceptId: string;
  lastSeenAt: number; // test index or timestamp
  intervalTests: number;
  masteredStreak: number;
}

export function nextReviewInterval(entry: ReviewEntry, wasCorrect: boolean): ReviewEntry {
  if (wasCorrect) {
    const masteredStreak = entry.masteredStreak + 1;
    const intervalTests = Math.min(20, Math.round(entry.intervalTests * 1.8) || 2);
    return { ...entry, masteredStreak, intervalTests };
  }
  return { ...entry, masteredStreak: 0, intervalTests: 1 };
}

export function isDueForReview(entry: ReviewEntry, currentTestIndex: number): boolean {
  return currentTestIndex - entry.lastSeenAt >= entry.intervalTests;
}
