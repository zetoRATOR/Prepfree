import { describe, it, expect } from 'vitest';
import { irtProbCorrect, fisherInformation, selectMostInformative, thetaToLevel } from '../adaptiveEngine';

describe('irtProbCorrect', () => {
  it('returns 0.5 when ability exactly matches item difficulty', () => {
    expect(irtProbCorrect(0, 1, 0)).toBeCloseTo(0.5);
  });
  it('returns higher probability as ability exceeds difficulty', () => {
    expect(irtProbCorrect(2, 1, 0)).toBeGreaterThan(irtProbCorrect(0, 1, 0));
  });
});

describe('fisherInformation', () => {
  it('is maximized when theta equals item difficulty', () => {
    const atMatch = fisherInformation(0, 1, 0);
    const farAway = fisherInformation(3, 1, 0);
    expect(atMatch).toBeGreaterThan(farAway);
  });
});

describe('selectMostInformative', () => {
  it('picks the item closest to the student ability, not just the hardest one', () => {
    const candidates = [
      { id: 'easy', irt_a: 1, irt_b: -2 },
      { id: 'match', irt_a: 1, irt_b: 0.1 },
      { id: 'hard', irt_a: 1, irt_b: 4 },
    ];
    const picked = selectMostInformative(0, candidates);
    expect(picked?.id).toBe('match');
  });
  it('returns null for an empty candidate pool instead of throwing', () => {
    expect(selectMostInformative(0, [])).toBeNull();
  });
});

describe('thetaToLevel', () => {
  it('never returns a level below 1', () => {
    expect(thetaToLevel(-10)).toBeGreaterThanOrEqual(1);
  });
});
